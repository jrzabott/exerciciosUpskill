package org.upskill.listatarefas.model;

import java.util.List;

public class ListaTarefas {

    public enum ORDENACAO {INSERCAO, PRIORIDADE}
    
    private List<Tarefa> listaTarefas;

    //implementar todas as funcionalidades necessárias
    
}
