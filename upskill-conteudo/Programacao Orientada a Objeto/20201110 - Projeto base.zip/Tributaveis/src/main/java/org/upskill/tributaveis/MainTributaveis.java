package org.upskill.tributaveis;

public class MainTributaveis {

    public static void main(String[] args) {
        
    }
}