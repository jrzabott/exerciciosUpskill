
package org.upskill.matrizgenerica.main;

public class MainMatrizGenerica {

    public static void main(String[] args) {
        
    }
    
}
