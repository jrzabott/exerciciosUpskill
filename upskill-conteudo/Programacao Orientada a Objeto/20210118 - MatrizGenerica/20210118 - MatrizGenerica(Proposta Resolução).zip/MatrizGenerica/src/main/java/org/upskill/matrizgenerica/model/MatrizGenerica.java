
package org.upskill.matrizgenerica.model;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class MatrizGenerica<E> {

    private List< List<E> > matrizGenerica;
    private int numeroMaximoColunas;

    public MatrizGenerica() {
        this.matrizGenerica = new ArrayList<>();
        this.numeroMaximoColunas = 0;
    }

    public int getNumeroDeLinhas() {
        return this.matrizGenerica.size();
    }
    
    public int getNumeroDeColunas(int indiceLinha) {
        verificarIndiceLinha(indiceLinha);
        return this.matrizGenerica.get(indiceLinha).size();
    }

    public void limpar() {
        this.matrizGenerica.clear();
    }
    
    public E getElemento(int indiceLinha, int indiceColuna) {
        verificarIndices(indiceLinha, indiceColuna);
        
        return matrizGenerica.get(indiceLinha).get(indiceColuna);
    }
    
    public boolean adicionarLinha(Collection<? extends E> listaAdicionar) {
        
        List<E> novaLista = new ArrayList<>(listaAdicionar);
        if(listaAdicionar.size() > numeroMaximoColunas) {
            numeroMaximoColunas = listaAdicionar.size();
        }
        
        return matrizGenerica.add(novaLista);
//        return matrizGenerica.add(listaAdicionar);
    }
    
    public boolean contem (E elementoPesquisar) {
        for (List<E> linha : matrizGenerica) {
            if(linha.contains(elementoPesquisar)) {
                return true;
            }
        }
        
        return false;
    }
    
    public boolean contem (List<E> linhaPesquisar) {
        return matrizGenerica.contains(linhaPesquisar);
    }
    
    public E substituir(int indiceLinha, int indiceColuna, E novoElemento) {
        verificarIndices(indiceLinha, indiceColuna);
        
        return matrizGenerica.get(indiceLinha).set(indiceColuna, novoElemento);
    }
     
    public List<E> eliminarLinha(int indiceLinha) {
        verificarIndiceLinha(indiceLinha);
        
        return matrizGenerica.remove(indiceLinha);
    }
    
    public <T> T[] elementosDaColuna(int indiceColuna, T []elementosDaColuna) {
        verificarIndiceColuna(indiceColuna);
        int numeroLinhas = tamanhoColuna(indiceColuna);
        
        if(elementosDaColuna == null || elementosDaColuna.length < numeroLinhas) {
            //caso não tenha sido iniciado
            elementosDaColuna = (T[]) Array.newInstance(elementosDaColuna.getClass().getComponentType(), numeroLinhas);
        }
        
        int pos=0;
        for (List<E> linha : matrizGenerica) {
            if(linha.size()>=indiceColuna) {
                elementosDaColuna[pos++] = (T) linha.get(indiceColuna);
            }            
        }
        
        if(elementosDaColuna.length > numeroLinhas) {
            elementosDaColuna[numeroLinhas] = null;
        }
        
        return elementosDaColuna;
    }
    
    private int tamanhoColuna(int indice){
        verificarIndiceColuna(indice);
        int numeroLinhas=0;
        for (List<E> linha : this.matrizGenerica) {
            if(indice<linha.size()){
                numeroLinhas++;
            }
        }
        return numeroLinhas;
    }
    
    private void verificarIndiceLinha(int indice) {
        if (indice < 0 || indice >= this.matrizGenerica.size()) {
            throw new IndexOutOfBoundsException(
                    "Índice Linha: " + indice
                    + ", Tamanho: " + this.matrizGenerica.size());
        }
    }

    private void verificarIndiceColuna(int indiceColuna) {
        if (indiceColuna < 0 || indiceColuna >= this.numeroMaximoColunas) {
            throw new IndexOutOfBoundsException(
                    " Índice Coluna: " + indiceColuna
                    + ", Tamanho: " + this.numeroMaximoColunas);
        }
    }
    
    private void verificarIndices(int indiceLinha, int indiceColuna) {
        if (indiceLinha < 0
                || indiceLinha >= this.matrizGenerica.size()
                || indiceColuna < 0
                || indiceColuna >= this.matrizGenerica.get(indiceLinha).size()) {
            String mensagem = mensagemIndiceLinhaInvalido(indiceLinha) + 
                    mensagemIndiceColunaInvalido(indiceColuna);
            throw new IndexOutOfBoundsException(mensagem);
        }
    }

    private String mensagemIndiceLinhaInvalido(int indice) {
        return "Índice Linha: " + indice
                + ", Tamanho: " + this.matrizGenerica.size();
    }
    
    private String mensagemIndiceColunaInvalido(int indice) {
        return  " Índice Coluna: " + indice
                + ", Tamanho: " + this.matrizGenerica.get(indice).size();
    }

}
