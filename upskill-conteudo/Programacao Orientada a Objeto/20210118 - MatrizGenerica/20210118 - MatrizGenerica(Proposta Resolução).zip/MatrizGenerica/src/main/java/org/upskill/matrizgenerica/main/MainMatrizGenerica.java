package org.upskill.matrizgenerica.main;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import org.upskill.matrizgenerica.model.MatrizGenerica;
import org.upskill.matrizgenerica.model.Trabalhador;
import org.upskill.matrizgenerica.model.TrabalhadorPeca;

public class MainMatrizGenerica {

    public static void main(String[] args) {
        //MatrizGenerica<int> matrizInt = new MatrizGenerica<>();

        //MatrizGenerica<Comparable<String>> matrizInt = new MatrizGenerica<>();
//        MatrizGenerica<Trabalhador> matrizTrabalhador;
        MatrizGenerica<TrabalhadorPeca> matrizTrabPeca = new MatrizGenerica<>();

//        matrizTrabalhador = matrizTrabPeca;
        TrabalhadorPeca tp1 = new TrabalhadorPeca("nome1");
        TrabalhadorPeca tp2 = new TrabalhadorPeca("nome2");
        TrabalhadorPeca tp3 = new TrabalhadorPeca("nome3");
        TrabalhadorPeca tp4 = new TrabalhadorPeca("nome4");
        
        List<TrabalhadorPeca> lista = new ArrayList<>();
        lista.add(tp4);
        lista.add(tp1);
        
        Queue<TrabalhadorPeca> fila = new LinkedList<>();
        fila.add(tp1);
        fila.add(tp2);
        fila.add(tp3);
        
        matrizTrabPeca.adicionarLinha(lista);
        imprimeMatriz(matrizTrabPeca);
        
        System.out.println("---");
        matrizTrabPeca.adicionarLinha(fila);
        imprimeMatriz(matrizTrabPeca);
        
        System.out.println("---");
        System.out.println("Linha removida: " + matrizTrabPeca.eliminarLinha(0));
        System.out.println("--- (após remoção)");
        imprimeMatriz(matrizTrabPeca);
        
    }

    private static void imprimeMatriz(MatrizGenerica<TrabalhadorPeca> matriz) {
        for (int i = 0; i < matriz.getNumeroDeLinhas(); i++) {
            for (int j = 0; j < matriz.getNumeroDeColunas(i); j++) {
                System.out.println(matriz.getElemento(i, j));
            }
            
            System.out.println("");
        }
    }
}
