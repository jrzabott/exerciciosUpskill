/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.upskill.vencimentos;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author user
 */
public class TrabalhadorVencimentoComparatorTest {
    
    public TrabalhadorVencimentoComparatorTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of compare method, of class TrabalhadorVencimentoComparator.
     */
    @Test
    public void testCompareEqual() {
        System.out.println("compare");
        Trabalhador o1 = null;
        Trabalhador o2 = null;
        TrabalhadorVencimentoComparator instance = new TrabalhadorVencimentoComparator();
        int expResult = 0;
        int result = instance.compare(o1, o2);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of compare method, of class TrabalhadorVencimentoComparator.
     */
    @Test
    public void testCompareLesser() {
        System.out.println("compare");
        Trabalhador o1 = null;
        Trabalhador o2 = null;
        TrabalhadorVencimentoComparator instance = new TrabalhadorVencimentoComparator();
        int expResult = 0;
        int result = instance.compare(o1, o2);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of compare method, of class TrabalhadorVencimentoComparator.
     */
    @Test
    public void testCompareGreater() {
        System.out.println("compare");
        Trabalhador o1 = null;
        Trabalhador o2 = null;
        TrabalhadorVencimentoComparator instance = new TrabalhadorVencimentoComparator();
        int expResult = 0;
        int result = instance.compare(o1, o2);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
